//
//  ViewController.swift
//  Favias2
//
//  Created by student on 30.10.2023.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var ButtonOne: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

