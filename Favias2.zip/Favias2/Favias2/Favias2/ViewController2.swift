//
//  ViewController.swift
//  Favias2
//
//  Created by student on 30.10.2023.
//

import UIKit

class ViewController2: UIViewController {
    @IBOutlet var Button: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

